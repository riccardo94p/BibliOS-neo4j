## Thanks

We would like to thank

* Philipp Spachtholz, for his thorough analysis of the data and building the first [recommender](http://104.155.24.30/books/) based on goodbooks-10k
* Maciej Kula, for adding the dataset to [Spotlight](https://github.com/maciejkula/spotlight/pull/62)

and all the other people who supported this dataset.
